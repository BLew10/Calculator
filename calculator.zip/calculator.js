var nums = document.querySelectorAll(".nums");
var display = document.getElementById("display");
var operations = document.querySelectorAll(".operation")
console.log(operations[0].innerHTML)

var store = 0;
var operationUsed = ""

function displayNum(e) {
    display.innerHTML += e.innerHTML;
    display.innerHTML = parseInt(display.innerHTML)
}


function operationEvent (e) {
    store = parseInt(display.innerHTML);
    display.innerHTML = 0;
    operationUsed = e.innerHTML;
}

document.querySelector('#clears').addEventListener("click", function () {
    display.innerHTML = 0;
})



function equals() {
    if (operationUsed === "+") {
        display.innerHTML = store + parseInt(display.innerHTML)
    } else if (operationUsed === "-") {
        display.innerHTML = store - parseInt(display.innerHTML)
    } else if (operationUsed === "/") {
        display.innerHTML = store / parseInt(display.innerHTML)
    } else if (operationUsed === "*") {
        display.innerHTML = store * parseInt(display.innerHTML)
    }

}

for (var i = nums.length - 1; i >= 0; i--) {
    nums[i].addEventListener("click", function () {
        displayNum(this)
    })
}

for (var i = operations.length - 1; i >= 0; i--) {
    operations[i].addEventListener("click", function () {
        operationEvent(this)
    })
}


// function add() {
//     store = parseInt(display.innerHTML);
//     display.innerHTML = 0;
//     operationUsed = "+";
// }
// function multiply() {
//     store = parseInt(display.innerHTML);
//     display.innerHTML = 0;
//     operationUsed = "*";
// }
// function substract() {
//     store = parseInt(display.innerHTML);
//     display.innerHTML = 0;
//     operationUsed = "-";
// }
// function divide() {
//     store = parseInt(display.innerHTML);
//     display.innerHTML = 0;
//     operationUsed = "/";
// }